// src/services/apiService.js
const axios = require("axios");

class ApiService {
  constructor() {
    this.baseUrl = "https://fcsapi.com/api-v3/forex/history";
    this.accessKey = process.env.FCS_API_KEY || "oUVE6imBXNGicbnZbkQy";
  }

  async getForexData(pair, resolution) {
    try {
      const response = await axios.get(this.baseUrl, {
        params: {
          symbol: pair,
          access_key: this.accessKey,
          period: resolution,
        },
      });

      const transformData = (data) => {
        return Object.values(data).map((entry) => ({
          t: entry.t,
          o: parseFloat(entry.o),
          h: parseFloat(entry.h),
          l: parseFloat(entry.l),
          c: parseFloat(entry.c),
        }));
      };

      const transformedData = transformData(response?.data?.response);
      return transformedData;
    } catch (error) {
      throw new Error(`Failed to fetch forex data: ${error.message}`);
    }
  }
}

module.exports = ApiService;
